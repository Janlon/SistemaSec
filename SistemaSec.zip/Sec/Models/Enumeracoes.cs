﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sec.Models
{
    /// <summary>
    /// Enumeração para booleanos. Sim = 1, não =0.
    /// </summary>
    public enum Resposta { Não = 0, Sim = 1 }
}

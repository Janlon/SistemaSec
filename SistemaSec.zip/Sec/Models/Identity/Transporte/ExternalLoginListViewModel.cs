﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Sec.Models
{
   public class ExternalLoginListViewModel
    {
        public string ReturnUrl { get; set; }
    }
}

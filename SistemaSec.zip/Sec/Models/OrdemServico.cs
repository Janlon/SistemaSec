﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Sec.Models
{
    //[Table("OrdemServicos", Schema = "dbo")]
    //public class OrdemServico
    //{
    //    [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    //    [ScaffoldColumn(false)]
    //    public int Id { get; set; }

    //    [Display(Name = "Ordem", AutoGenerateField = true, AutoGenerateFilter = true, Prompt = "Ordem")]
    //    [Required(ErrorMessage = "{0} é obrigatório.")]
    //    [ForeignKey("Ordem")]
    //    public int OrdensId { get; set; }
    //    public virtual Ordem Ordem { get; set; }

    //    [Display(Name = "Servico", AutoGenerateField = true, AutoGenerateFilter = true, Prompt = "Servico")]
    //    [Required(ErrorMessage = "{0} é obrigatório.")]
    //    [ForeignKey("Servico")]
    //    public int ServicosId { get; set; }
    //    public virtual Servico Servico { get; set; }

    //    [Display(Name = "Equipamento", AutoGenerateField = true, AutoGenerateFilter = true, Prompt = "Equipamento")]
    //    [Required(ErrorMessage = "{0} é obrigatório.")]
    //    [ForeignKey("Equipamento")]
    //    public int EquipamentosId { get; set; }
    //    public virtual Equipamento Equipamento { get; set; }

    //}
}
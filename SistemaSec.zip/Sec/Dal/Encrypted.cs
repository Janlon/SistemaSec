﻿namespace System.ComponentModel.DataAnnotations
{
    public class EncryptedAttribute : Attribute    {    }
    public class EncryptionKeyAttribute : Attribute    {    }
    public class RecoverKeyAttribute : Attribute { }
    public class ActivationAttribute: Attribute { }
}
